# Bluey Android

Минимальный Android-прототип Bluey Assistant.

## Сборка APK
В GitHub Actions запустите workflow **Build Bluey Android** вручную (Actions → Build Bluey Android → Run workflow). После успешной сборки APK будет доступен в Artifacts под именем `BlueyAndroid-APK`.

Требования CI: Java 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2.

## Исправления в этом архиве
- Оставлена одна копия Android-проекта в корне архива; вложенный дубликат удалён.
- В `app/build.gradle.kts` согласованы цели Java и Kotlin: JVM 17.
- Workflow собирает `:app:assembleDebug` из корня проекта и завершает работу с ошибкой, если APK не найден.

Это пока прототип: голосовое распознавание и озвучивание реализованы базово; полноценный ИИ, постоянная память и автономное управление телефоном ещё не реализованы.
