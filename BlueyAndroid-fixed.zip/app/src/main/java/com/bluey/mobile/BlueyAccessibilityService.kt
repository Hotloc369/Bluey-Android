package com.bluey.mobile

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class BlueyAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Пока только принимает события Android.
        // Автоматические действия добавим позже.
    }

    override fun onInterrupt() {
        // Вызывается при прерывании службы.
    }
}