package com.bluey.mobile

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.view.WindowManager.LayoutParams

class BlueyOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var mascot: TextView? = null

    override fun onCreate() {
        super.onCreate()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        mascot = TextView(this).apply {
            text = "🐾"
            textSize = 42f
            gravity = Gravity.CENTER
            setPadding(16, 16, 16, 16)
        }

        val params = LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        mascot?.setOnTouchListener(object : android.view.View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(
                view: android.view.View,
                event: android.view.MotionEvent
            ): Boolean {
                when (event.action) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(view, params)
                        return true
                    }
                }
                return false
            }
        })

        if (android.provider.Settings.canDrawOverlays(this)) {
            windowManager.addView(mascot, params)
        }
    }

    override fun onDestroy() {
        mascot?.let {
            windowManager.removeView(it)
        }
        mascot = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}