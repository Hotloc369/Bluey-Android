# Bluey Android — corrected project archive

This archive contains exactly one Android Gradle project at `BlueyAndroid/`.

## Build
The repository workflow should unpack this archive and run:
`gradle -p project/BlueyAndroid :app:assembleDebug`

Requirements:
- JDK 17
- Gradle 8.11.1
- Android Gradle Plugin 8.9.2
- Kotlin 2.0.21

## JVM compatibility
The app explicitly sets Java source/target compatibility to 17 and Kotlin `jvmTarget` to 17.

## Important
This is a corrected source project archive, not a prebuilt APK. A successful APK build must still be confirmed by GitHub Actions.
The current app is an early prototype; it does not yet contain a full AI assistant.
